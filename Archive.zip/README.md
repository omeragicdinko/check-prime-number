# check-prime-number
A simple prime number checker using AWS Lambda functions.
